import json, zipfile, uuid, datetime, sys, os
import numpy as np, trimesh

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, 'profils') + '/'
OUT = sys.argv[1]
STL = os.path.join(HERE, '..', 'stl') + '/'
APP_VER = '02.08.04.61'

machine = json.load(open(D + 'resolved_Bambu_Lab_P1S_0.4_nozzle.json'))
fil     = json.load(open(D + 'resolved_Bambu_PLA_Matte_BBL_P1S_0.4_nozzle.json'))
proc    = json.load(open(D + 'resolved_0.20mm_Standard_BBL_X1C.json'))
V       = json.load(open(D + 'variant_sets.json'))

META = {'name', 'inherits', 'include', 'instantiation', 'setting_id', 'type', 'from',
        'description', 'compatible_printers', 'compatible_printers_condition',
        'compatible_prints', 'compatible_prints_condition', 'filament_id', 'is_custom_defined',
        'version', 'renamed_from', 'base_id', 'filament_vendor_id'}

def collapse(cfg, single, double):
    out = {}
    for k, v in cfg.items():
        if k in META:
            continue
        if k in single and isinstance(v, list) and len(v) >= 1:
            v = [v[0]]                      # index 0 = "Direct Drive Standard"
        elif k in double and isinstance(v, list) and len(v) >= 2:
            v = v[:2]                       # normal + silent of variant 0
        out[k] = v
    return out

cfg = {}
cfg.update(collapse(machine, set(V['printer_options_with_variant_1']), set(V['printer_options_with_variant_2'])))
cfg.update(collapse(proc, set(V['print_options_with_variant']), set()))
cfg.update(collapse(fil, set(V['filament_options_with_variant']), set()))

cfg.update({
    'name': 'project_settings',
    'from': 'project',
    'version': APP_VER,
    'printer_settings_id': 'Bambu Lab P1S 0.4 nozzle',
    'print_settings_id': '0.20mm Standard @BBL X1C',
    'filament_settings_id': ['Bambu PLA Matte @BBL P1S 0.4 nozzle'],
    'print_compatible_printers': proc.get('compatible_printers', []),
    'filament_ids': [fil.get('filament_id', 'GFA01')],
    'filament_colour': ['#9B9EA0'],
    'default_filament_colour': [''],
    'filament_map': ['1'],
    'filament_self_index': ['1'],
    'filament_map_mode': 'Auto For Flush',
    'nozzle_volume_type': ['Standard'],
    'curr_bed_type': 'Textured PEI Plate',
    'different_settings_to_system': ['', '', ''],
    'inherits_group': ['', '', ''],
    'flush_volumes_matrix': ['0'],
    'flush_volumes_vector': ['140', '140'],
    'flush_multiplier': ['1'],
})

# ---------- géométrie ----------
parts = [  # (fichier, nom, plaque, x, y)
    ('fond_integre_L', 'Fond L (une piece)',            1,  72, 186),
    ('couvercle',      'Couvercle',                     1, 186, 186),
    ('bague_L',        'Bague L (haut)',                1,  72,  72),
    ('manchon_L',      'Manchon L (option double box)', 1, 186,  72),
]
PLATES = {1: 'Boite L - kit complet'}
STRIDE = 256 * 1.2      # plaques sur 2 colonnes

def fmt(x):
    return ('%.6f' % x).rstrip('0').rstrip('.') if abs(x) > 1e-12 else '0'

files = {}
main_objs, build_items, plate_inst, cfg_objs, assemble = [], [], {p: [] for p in PLATES}, [], []
NS = ('xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" '
      'xmlns:BambuStudio="http://schemas.bambulab.com/package/2021" '
      'xmlns:p="http://schemas.microsoft.com/3dmanufacturing/production/2015/06" requiredextensions="p"')
n = len(parts)
for k, (stl, name, plate, x, y) in enumerate(parts, 1):
    m = trimesh.load(STL + stl + '.stl', process=True)
    m.merge_vertices()
    assert m.is_watertight, stl
    c = m.bounds.mean(axis=0)
    m.apply_translation(-c)                      # maillage centré sur son origine
    h = m.extents[2]
    sub_id, top_id = k, n + k
    path = f'3D/Objects/object_{k}.model'
    vx = ''.join(f'<vertex x="{fmt(a)}" y="{fmt(b)}" z="{fmt(cc)}"/>' for a, b, cc in m.vertices)
    tr = ''.join(f'<triangle v1="{a}" v2="{b}" v3="{cc}"/>' for a, b, cc in m.faces)
    files[path] = (f'<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" {NS}>\n'
                   f' <metadata name="BambuStudio:3mfVersion">1</metadata>\n <resources>\n'
                   f'  <object id="{sub_id}" p:UUID="{uuid.uuid4()}" type="model">\n'
                   f'   <mesh><vertices>{vx}</vertices><triangles>{tr}</triangles></mesh>\n'
                   f'  </object>\n </resources>\n <build/>\n</model>\n')
    main_objs.append(f'  <object id="{top_id}" p:UUID="{uuid.uuid4()}" type="model">\n   <components>\n'
                     f'    <component p:path="/{path}" objectid="{sub_id}" p:UUID="{uuid.uuid4()}" transform="1 0 0 0 1 0 0 0 1 0 0 0"/>\n'
                     f'   </components>\n  </object>')
    i = plate - 1
    wx = x + (i % 2) * STRIDE
    wy = y - (i // 2) * STRIDE
    t = f'1 0 0 0 1 0 0 0 1 {fmt(wx)} {fmt(wy)} {fmt(h / 2)}'
    build_items.append(f'  <item objectid="{top_id}" p:UUID="{uuid.uuid4()}" transform="{t}" printable="1"/>')
    plate_inst[plate].append(top_id)
    cfg_objs.append(
        f'  <object id="{top_id}">\n'
        f'    <metadata key="name" value="{name}"/>\n'
        f'    <metadata key="extruder" value="1"/>\n'
        f'    <metadata face_count="{len(m.faces)}"/>\n'
        f'    <part id="1" subtype="normal_part">\n'
        f'      <metadata key="name" value="{name}"/>\n'
        f'      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>\n'
        f'      <metadata key="source_file" value="boites_modulaires.scad"/>\n'
        f'      <metadata key="source_object_id" value="{k - 1}"/>\n'
        f'      <metadata key="source_volume_id" value="0"/>\n'
        f'      <metadata key="source_offset_x" value="0"/>\n'
        f'      <metadata key="source_offset_y" value="0"/>\n'
        f'      <metadata key="source_offset_z" value="0"/>\n'
        f'      <mesh_stat face_count="{len(m.faces)}" edges_fixed="0" degenerate_facets="0" facets_removed="0" facets_reversed="0" backwards_edges="0"/>\n'
        f'    </part>\n  </object>')
    assemble.append(f'   <assemble_item object_id="{top_id}" instance_id="0" transform="{t}" offset="0 0 0" />')
    print(name, 'plaque', plate, 'faces', len(m.faces), 'h', round(h, 2))

today = datetime.date.today().isoformat()
meta = {'Application': f'BambuStudio-{APP_VER}', 'BambuStudio:3mfVersion': '1', 'Copyright': '',
        'CreationDate': today, 'Description': 'Boîtes modulaires pour tubes carton de bobines',
        'Designer': '', 'DesignerCover': '', 'DesignerUserId': '', 'License': '', 'ModificationDate': today,
        'Origin': '', 'Title': 'Boîtes modulaires - kit'}
files['3D/3dmodel.model'] = (
    f'<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" {NS}>\n'
    + ''.join(f' <metadata name="{k}">{v}</metadata>\n' for k, v in meta.items())
    + ' <resources>\n' + '\n'.join(main_objs) + '\n </resources>\n'
    + f' <build p:UUID="2c7c17d8-22b5-4d84-8835-1976022ea369">\n' + '\n'.join(build_items) + '\n </build>\n</model>\n')
files['3D/_rels/3dmodel.model.rels'] = (
    '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
    + ''.join(f' <Relationship Target="/3D/Objects/object_{k}.model" Id="rel-{k}" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n' for k in range(1, n + 1))
    + '</Relationships>\n')

ident = 1000
plates_xml = []
for p in PLATES:
    inst = ''
    for oid in plate_inst[p]:
        ident += 17
        inst += ('    <model_instance>\n'
                 f'      <metadata key="object_id" value="{oid}"/>\n'
                 '      <metadata key="instance_id" value="0"/>\n'
                 f'      <metadata key="identify_id" value="{ident}"/>\n'
                 '    </model_instance>\n')
    pname = PLATES[p]
    plates_xml.append('  <plate>\n'
                      f'    <metadata key="plater_id" value="{p}"/>\n'
                      f'    <metadata key="plater_name" value="{pname}"/>\n'
                      '    <metadata key="locked" value="false"/>\n'
                      '    <metadata key="filament_map_mode" value="Auto For Flush"/>\n'
                      f'    <metadata key="thumbnail_file" value="Metadata/plate_{p}.png"/>\n'
                      + inst + '  </plate>')
files['Metadata/model_settings.config'] = (
    '<?xml version="1.0" encoding="UTF-8"?>\n<config>\n' + '\n'.join(cfg_objs) + '\n' + '\n'.join(plates_xml)
    + '\n  <assemble>\n' + '\n'.join(assemble) + '\n  </assemble>\n</config>\n')
files['Metadata/project_settings.config'] = json.dumps(cfg, indent=4, ensure_ascii=False)
files['Metadata/slice_info.config'] = (
    '<?xml version="1.0" encoding="UTF-8"?>\n<config>\n  <header>\n'
    '    <header_item key="X-BBL-Client-Type" value="slicer"/>\n'
    f'    <header_item key="X-BBL-Client-Version" value="{APP_VER}"/>\n  </header>\n</config>\n')
files['Metadata/cut_information.xml'] = (
    '<?xml version="1.0" encoding="utf-8"?>\n<objects>\n'
    + ''.join(f' <object id="{k}">\n  <cut_id id="0" check_sum="1" connectors_cnt="0"/>\n </object>\n' for k in range(1, n + 1))
    + '</objects>\n')
files['[Content_Types].xml'] = (
    '<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\n'
    ' <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\n'
    ' <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>\n'
    ' <Default Extension="png" ContentType="image/png"/>\n'
    ' <Default Extension="gcode" ContentType="text/x.gcode"/>\n</Types>\n')
files['_rels/.rels'] = (
    '<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
    ' <Relationship Target="/3D/3dmodel.model" Id="rel-1" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>\n'
    '</Relationships>\n')

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in ['[Content_Types].xml', '_rels/.rels', '3D/3dmodel.model', '3D/_rels/3dmodel.model.rels']:
        z.writestr(name, files.pop(name))
    for name, data in files.items():
        z.writestr(name, data)
    for p in PLATES:   # vignettes facultatives : profils/plate_<n>.png
        if os.path.exists(f'{D}plate_{p}.png'):
            z.write(f'{D}plate_{p}.png', f'Metadata/plate_{p}.png')
print('settings keys:', len(cfg))
