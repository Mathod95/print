import json, os, sys, urllib.request, urllib.parse
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'profils')
B='https://raw.githubusercontent.com/bambulab/BambuStudio/v02.08.04.61/resources/profiles/BBL/'
idx=json.load(open(f'{D}/BBL.json'))
paths={}
for k in ['machine_model_list','machine_list','process_list','filament_list']:
    for e in idx.get(k,[]): paths[e['name']]=e['sub_path']
def load(name):
    sp=paths[name]; fn=os.path.join(D,'cache',sp)
    if not os.path.exists(fn):
        os.makedirs(os.path.dirname(fn),exist_ok=True)
        urllib.request.urlretrieve(B+urllib.parse.quote(sp), fn)
    return json.load(open(fn))
def resolve(name):
    d=load(name); chain=[name]
    base={}
    if d.get('inherits'):
        base,c=resolve(d['inherits']); chain=c+chain
    out=dict(base)
    for inc in d.get('include',[]) or []:
        di=load(inc)
        out.update({k:v for k,v in di.items() if k not in ('name','type','from','instantiation','setting_id','inherits','include')})
    out.update(d)
    return out,chain
if __name__=='__main__':
    for n in sys.argv[1:]:
        r,c=resolve(n); print(n,'<-',c, len(r),'keys')
        json.dump(r,open(f"{D}/resolved_{n.replace(' ','_').replace('@','')}.json",'w'),indent=1)
